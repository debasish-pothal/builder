import { Observable } from 'rxjs';
import { EffectNotification } from './effect_notification';
export declare function mergeEffects(sourceInstance: any): Observable<EffectNotification>;
