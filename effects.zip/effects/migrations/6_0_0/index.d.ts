/// <amd-module name="@ngrx/effects/migrations/6_0_0/index" />
import { Rule } from '@angular-devkit/schematics';
export default function (): Rule;
