/// <amd-module name="@ngrx/effects/schematics-core/utility/libs-version" />
export declare const platformVersion = "^7.0.0";
