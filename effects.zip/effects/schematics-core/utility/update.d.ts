/// <amd-module name="@ngrx/effects/schematics-core/utility/update" />
import { Rule } from '@angular-devkit/schematics';
export declare function updatePackage(name: string): Rule;
