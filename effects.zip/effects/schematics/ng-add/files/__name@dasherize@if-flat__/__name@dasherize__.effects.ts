import { Injectable } from '@angular/core';
import { Actions, Effect } from '@ngrx/effects';

@Injectable()
export class <%= classify(name) %>Effects {
  constructor(private actions$: Actions) {}
}
