/// <amd-module name="@ngrx/effects/schematics/ng-add/index" />
import { Rule } from '@angular-devkit/schematics';
import { Schema as RootEffectOptions } from './schema';
export default function (options: RootEffectOptions): Rule;
